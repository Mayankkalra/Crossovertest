package com.crossover.e2e;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.testng.annotations.BeforeMethod;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.eclipse.jetty.util.thread.Timeout;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class GMailTest {
    private WebDriver driver;
    private Properties properties = new Properties();

    @BeforeMethod
	public void setUp() throws Exception {
        System.out.println(System.getProperty("user.dir")+"/src/test/resources/test.properties");
        File file = new File(System.getProperty("user.dir")+"/src/test/resources/test.properties");
        FileInputStream fis = new FileInputStream(file);
        properties.load(fis);
       System.out.println(properties.getProperty("webdriver.chrome.driver"));
        //Dont Change below line. Set this value in test.properties file incase you need to change it..
//        File file = new File("C:\\chromedriver.exe");
        System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+properties.getProperty("webdriver.chrome.driver") );
        driver = new ChromeDriver();
    }

    @AfterMethod
	public void tearDown() throws Exception {
        driver.quit();
    }

    /*
     * Please focus on completing the task
     * 
     */
    @Test
    public void testSendEmail() throws Exception {
        driver.get("https://mail.google.com/");
        driver.manage().window().maximize();
        Reporter.log("Launched  Gmail");
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
       
        
        WebElement userElement = driver.findElement(By.id("identifierId"));
        userElement.sendKeys(properties.getProperty("username"));
        Reporter.log("Username entered");


        driver.findElement(By.id("identifierNext")).click();


        Thread.sleep(1000);

        WebElement passwordElement = driver.findElement(By.name("password"));
        passwordElement.sendKeys(properties.getProperty("password"));
        driver.findElement(By.id("passwordNext")).click();
        Reporter.log("Loggedin in Gmail");

        Thread.sleep(8000);
        WebDriverWait wait=new WebDriverWait(driver, 20);
        WebElement composeElement = driver.findElement(By.xpath("//div[@role='button' and text()='Compose']"));
        wait.until(ExpectedConditions.visibilityOf(composeElement))   ;     
        composeElement.click();
        Reporter.log("Gmail open and clicked on Compose mail");


        driver.findElement(By.name("to")).clear();
//        driver.findElement(By.name("to")).sendKeys(String.format("%s@gmail.com", properties.getProperty("username")));
        driver.findElement(By.name("to")).sendKeys(properties.getProperty("username"));

        // emailSubject and emailbody to be used in this unit test.
        String emailSubject = properties.getProperty("email.subject");
        String emailBody = properties.getProperty("email.body"); 
        driver.findElement(By.xpath("//input[@name='subjectbox']")).sendKeys(emailSubject);
        Reporter.log(" Email Subject has been set");

        driver.findElement(By.xpath("//div[@aria-label=\"Message Body\"]")).sendKeys(emailBody);
        Reporter.log(" Email body has been set");

        driver.findElement(By.xpath("//div[@data-tooltip=\"More options\"]")).click();
        WebElement findElement_Label = driver.findElement(By.xpath("//div[text()=\"Label\"]/span"));
        Actions builder = new Actions(driver); 

        builder.moveToElement(findElement_Label).click().perform();
        Thread.sleep(4000);
        WebElement findElement_Label_Social = driver.findElement(By.xpath("//div[@role=\"menuitemcheckbox\"]/div[text()=\"Social\"]/div"));
        builder.moveToElement(findElement_Label_Social).click().perform();
        Thread.sleep(4000);
//        driver.findElement(By.xpath("//div[@data-tooltip=\"More options\"]")).click();
        Reporter.log(" Mark Label as Social");

        driver.findElement(By.xpath("//*[@role='button' and text()='Send']")).click();
       
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Message sent')]")));                                                   
        List<WebElement> inboxEmails = wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath("//*[@class='zA zE']"))));                   

        for(WebElement email : inboxEmails){                                                                                                                           
            if(email.isDisplayed() && email.getText().contains(emailSubject)){  
            	email.findElement(By.xpath("//span[@class='aXw T-KT']")).click();
                Reporter.log("Verify email came under proper Label i.e. \"Social\"\n" + 
                		"");

                email.click();                                                                                                                                         
                SoftAssert softAssertion= new SoftAssert();
                WebElement label = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(@title,'with label Inbox')]")));
                boolean displayed = label.isDisplayed();
                softAssertion.assertTrue(displayed);

                WebElement subject = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[contains(text(),'"+emailSubject+"')]")));
                boolean displayed_subject = subject.isDisplayed();
                softAssertion.assertTrue(displayed_subject);
                WebElement body = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'"+emailBody+"')]")));   
                boolean displayed_body = body.isDisplayed();
                softAssertion.assertTrue(displayed_body);
                softAssertion.assertAll();
                Reporter.log("Verify the subject and body of the received email");
                break;

            }                                                                                                                                                          
        } 
        
    }
}
